import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { getOrders, updateOrder } from '../services/filesService';
import { checkOrderStatus, generateDownloadLink } from '../services/stockService';
import type { Order } from '../types';
import { ArrowPathIcon, CheckCircleIcon, XCircleIcon, ArrowDownTrayIcon, ServerIcon, MagnifyingGlassIcon } from './icons/Icons';
import { Link } from 'react-router-dom';

const useOrderPolling = (orders: Order[], onUpdate: (taskId: string, newStatus: Order['status']) => void) => {
    useEffect(() => {
        const processingOrders = orders.filter(o => o.status === 'processing');
        if (processingOrders.length === 0) return;

        const interval = setInterval(async () => {
            for (const order of processingOrders) {
                try {
                    const statusResult = await checkOrderStatus(order.task_id);
                    if (statusResult.status === 'ready' || statusResult.status === 'failed') {
                        await updateOrder(order.task_id, { status: statusResult.status });
                        onUpdate(order.task_id, statusResult.status);
                    }
                } catch (err) {
                    console.error(`Failed to check status for ${order.task_id}`, err);
                    await updateOrder(order.task_id, { status: 'failed' });
                    onUpdate(order.task_id, 'failed');
                }
            }
        }, 5000); // Poll every 5 seconds

        return () => clearInterval(interval);
    }, [orders, onUpdate]);
};


const FilesManager = () => {
    const { t } = useLanguage();
    const { user } = useAuth();
    const [orders, setOrders] = useState<Order[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [downloading, setDownloading] = useState<Set<string>>(new Set());
    const [searchQuery, setSearchQuery] = useState('');

    const handleUpdate = (taskId: string, newStatus: Order['status']) => {
        setOrders(prevOrders =>
            prevOrders.map(o => o.task_id === taskId ? { ...o, status: newStatus } : o)
        );
    };

    useOrderPolling(orders, handleUpdate);

    useEffect(() => {
        if (!user) return;
        const fetchOrders = async () => {
            setIsLoading(true);
            try {
                const userOrders = await getOrders(user.id);
                setOrders(userOrders);
            } catch (err: any) {
                setError(err.message);
            } finally {
                setIsLoading(false);
            }
        };
        fetchOrders();
    }, [user]);
    
    const filteredOrders = useMemo(() => {
        if (!searchQuery.trim()) {
            return orders;
        }
        const lowercasedQuery = searchQuery.toLowerCase().trim();
        return orders.filter(order => {
            const { id, site, debugid } = order.file_info;
            
            // Check against file ID, site name, or debug ID
            if (id.toLowerCase().includes(lowercasedQuery) ||
                site.toLowerCase().includes(lowercasedQuery) ||
                (debugid && debugid.toLowerCase().includes(lowercasedQuery))) {
                return true;
            }
            
            // Heuristic for URL search: check if the query is a URL-like string that contains the file ID
            if (lowercasedQuery.includes(id.toLowerCase()) && lowercasedQuery.length > id.length) {
                return true;
            }

            return false;
        });
    }, [orders, searchQuery]);


    const handleDownload = async (taskId: string) => {
        setDownloading(prev => new Set(prev).add(taskId));
        try {
            const { url } = await generateDownloadLink(taskId);
            window.open(url, '_blank');
        } catch (err) {
            alert('Could not generate download link.');
        } finally {
            setDownloading(prev => {
                const newSet = new Set(prev);
                newSet.delete(taskId);
                return newSet;
            });
        }
    };
    
    const StatusIndicator = ({ status }: { status: Order['status'] }) => {
        const statusMap = {
            processing: { text: t('processingStatus'), icon: <ArrowPathIcon className="w-4 h-4 animate-spin" />, color: 'text-yellow-400' },
            ready: { text: t('readyStatus'), icon: <CheckCircleIcon className="w-4 h-4" />, color: 'text-green-400' },
            failed: { text: t('failedStatus'), icon: <XCircleIcon className="w-4 h-4" />, color: 'text-red-400' },
        };
        const current = statusMap[status];
        return (
            <div className={`flex items-center space-x-2 rtl:space-x-reverse text-sm font-semibold ${current.color}`}>
                {current.icon}
                <span>{current.text}</span>
            </div>
        )
    };
    
    const renderContent = () => {
        if (isLoading) {
            return <div className="text-center py-10"><ArrowPathIcon className="w-8 h-8 animate-spin mx-auto text-blue-500" /></div>;
        }
        if (error) {
            return <div className="text-center py-10 text-red-400">{error}</div>;
        }
        if (orders.length === 0) {
            return (
                <div className="text-center py-16">
                    <ServerIcon className="w-16 h-16 mx-auto text-gray-500 mb-4" />
                    <h3 className="text-xl font-semibold text-white">{t('noFilesFound')}</h3>
                    <p className="text-gray-400 mt-2">{t('noFilesFoundDesc')}</p>
                    <Link to="/stock" className="mt-4 inline-block bg-blue-600 text-white font-bold py-2 px-5 rounded-lg hover:bg-blue-700 transition-colors">{t('downloadStockFile')}</Link>
                </div>
            );
        }
         if (filteredOrders.length === 0) {
            return (
                 <div className="text-center py-16">
                    <MagnifyingGlassIcon className="w-16 h-16 mx-auto text-gray-500 mb-4" />
                    <h3 className="text-xl font-semibold text-white">{t('noResultsFound', { query: searchQuery })}</h3>
                    <p className="text-gray-400 mt-2">{t('noResultsFoundDesc')}</p>
                </div>
            );
        }
        return (
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-700">
                    <thead className="bg-gray-800">
                        <tr>
                            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-gray-300 uppercase tracking-wider">{t('file')}</th>
                            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-gray-300 uppercase tracking-wider">{t('source')}</th>
                            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-gray-300 uppercase tracking-wider">{t('date')}</th>
                            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-gray-300 uppercase tracking-wider">{t('cost')}</th>
                            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-gray-300 uppercase tracking-wider">{t('debugId')}</th>
                            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-gray-300 uppercase tracking-wider">{t('status')}</th>
                            <th scope="col" className="px-6 py-3 text-end text-xs font-medium text-gray-300 uppercase tracking-wider">{t('action')}</th>
                        </tr>
                    </thead>
                    <tbody className="bg-gray-800/50 divide-y divide-gray-700">
                        {filteredOrders.map(order => (
                            <tr key={order.id}>
                                <td className="px-6 py-4 whitespace-nowrap"><img src={order.file_info.preview} alt="preview" className="w-16 h-10 rounded object-cover" /></td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm">
                                    <div className="font-semibold text-gray-300">{order.file_info.site}</div>
                                    <div className="text-xs text-gray-400 font-mono">{order.file_info.id}</div>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">{new Date(order.created_at).toLocaleDateString()}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{order.file_info.cost?.toFixed(2)}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-xs font-mono text-gray-400">{order.file_info.debugid || 'N/A'}</td>
                                <td className="px-6 py-4 whitespace-nowrap"><StatusIndicator status={order.status} /></td>
                                <td className="px-6 py-4 whitespace-nowrap text-end">
                                    {order.status === 'ready' && (
                                        <button
                                            onClick={() => handleDownload(order.task_id)}
                                            disabled={downloading.has(order.task_id)}
                                            className="bg-blue-600 text-white font-bold py-2 px-3 rounded-lg hover:bg-blue-700 disabled:bg-blue-400 disabled:cursor-wait transition-colors flex items-center text-sm"
                                        >
                                            {downloading.has(order.task_id) ? <ArrowPathIcon className="w-4 h-4 animate-spin me-2" /> : <ArrowDownTrayIcon className="w-4 h-4 me-2" />}
                                            {t('downloadNow')}
                                        </button>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        );
    };

    return (
        <div className="animate-fadeIn">
            <h1 className="text-3xl font-bold mb-2">{t('filesManagerTitle')}</h1>
            <p className="text-gray-400 mb-6">{t('filesManagerSubtitle')}</p>

             {orders.length > 0 && (
                <div className="relative mb-4">
                    <div className="pointer-events-none absolute inset-y-0 start-0 flex items-center ps-3.5">
                        <MagnifyingGlassIcon className="w-5 h-5 text-gray-400" />
                    </div>
                    <input
                        type="search"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder={t('searchPlaceholder')}
                        className="w-full ps-10 p-3 bg-gray-700/80 border border-transparent rounded-lg focus:ring-blue-500 focus:border-blue-500 text-white placeholder-gray-400"
                    />
                </div>
            )}
            
            <div className="bg-gray-800/80 rounded-xl shadow-lg p-1 glassmorphism">
                {renderContent()}
            </div>
        </div>
    );
};

export default FilesManager;